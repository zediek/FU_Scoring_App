//
//  ViewController.swift
//  FU Scoring App
//
//  Created by Neil Steven Villamil on 10/1/19.
//  Copyright © 2019 Neil Steven Villamil. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

